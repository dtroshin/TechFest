import java.applet.*;
import java.awt.*;

public class Lab6 extends Applet{
	public static void main(String [] args) {
        FrameBuffer fb = new FrameBuffer();
        fb.display();
        int x = 0, y = 0;
        while (x < fb.getWidth()) {
            while (x < fb.getWidth() && y < fb.getHeight())
                fb.setPixel(x++, y++);
            y--;

            while (x < fb.getWidth() && y >= 0)
                fb.setPixel(x++, y--);
            if (y < 0)y = 0;
        }

        fb.display();
        fb.clear();
        fb.display();
    }
}

class FrameBuffer {
    FrameBuffer(int width, int height) {}	// Creates a frame buffer of specified resolution 
    FrameBuffer() {}		 		 // Creates a default-sized frame buffer

    public void setPixel(int x, int y, boolean b) {} // Sets pixel (x, y) to b
    public void setPixel(int x, int y) {}			 // Sets pixel (x, y) to true 

    public int getWidth() {return 1;}
    public int getHeight() {return 1;}

    public void clear() {}	 // Clears frame buffer

    public void display() {} // displays frame buffer on System.out as " "'s and "*"s
		
    private boolean pixels[][];
    private int width, height;
}

