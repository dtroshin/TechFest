import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class Lab5 extends Applet {
    public void init() {
        Button Normal = new Button("Normal");
		Button Stop = new Button("Stop");
		Button Caution = new Button("Caution");
		Button rTurn = new Button("Right Turn");
		Button Off = new Button("Off");
		
		setLayout(new BorderLayout());
		
		Panel Controls = new Panel();
		Controls.setLayout(new GridLayout(5,1));
		Controls.add(Normal);
		Controls.add(Stop);
		Controls.add(Caution);
		Controls.add(rTurn);
		Controls.add(Off);
		add(Controls, BorderLayout.WEST);
		
		Scrollbar speedControl = new Scrollbar(Scrollbar.VERTICAL, 0,0,0,100);
		add(speedControl, BorderLayout.EAST);
		
        BlinkCanvas blinkCanvas = new BlinkCanvas(Normal, Stop, Caution, rTurn,Off, speedControl);
        add(blinkCanvas, BorderLayout.CENTER);
		

        new BlinkThread(blinkCanvas).start();
		
    }
}

class BlinkCanvas extends Canvas implements ActionListener {
    BlinkCanvas(Button Normal, Button Stop, Button Caution, Button rTurn, Button Off, Scrollbar speedControl) {
        
		this.Normal = Normal;
		this.Stop = Stop;
		this.Caution = Caution;
		this.rTurn = rTurn;
		this.Off = Off;
		
        Normal.addActionListener(this);
		Stop.addActionListener(this);
		Caution.addActionListener(this);
		rTurn.addActionListener(this);
		Off.addActionListener(this);
        setSize(250, 400);
		Center = (getWidth()/2);
    }

    public void paint(Graphics g) {
		//Draw Outline of Traffic Single
		g.drawLine(0,((int)getWidth() / 3), Center, 20);
		g.drawLine(Center, 20, getWidth(), (int)(getWidth()/3));
		
		g.setColor(Color.BLACK);
		g.fillOval(Center-40, 80, 75, 75);
		g.fillOval(Center-40, 170, 75, 75);
		g.fillOval(Center-40, 260, 75, 75);
    }
	
	public void NormalSig(Graphics g){
		g.setColor(Color.BLACK);
        g.fillOval(Center-40, 80, 75, 75);
		g.fillOval(Center-40, 170, 75, 75);
		g.fillOval(Center-40, 260, 75, 75);
        
		
        g.setColor(Color.GREEN);
		g.fillOval(Center-40, 260, 75, 75);
		g.setColor(Color.BLACK);
		 try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {}
		g.fillOval(Center-40, 260, 75, 75);
		
		g.setColor(Color.ORANGE);
		g.fillOval(Center-40, 170, 75, 75);
		g.setColor(Color.BLACK);
		 try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {}
		g.fillOval(Center-40, 170, 75, 75);
		
		g.setColor(Color.RED);
		g.fillOval(Center-40, 80, 75, 75);
		g.setColor(Color.BLACK);
		 try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {}
		g.fillOval(Center-40, 80, 75, 75);
	}
	
	public void StopSig(Graphics g){
		while (true) {
				g.setColor(theColor);
				g.fillOval(Center-40, 170, 75, 75);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {}
				theColor = theColor == Color.RED ? Color.BLACK : Color.RED;
			}
	}
	
	public void CautionSig(Graphics g){
		while (true) {
				g.setColor(theColor);
				g.fillOval(Center-40, 170, 75, 75);
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {}
				theColor = theColor == Color.ORANGE ? Color.BLACK : Color.ORANGE;
			}
	}
	
	public void RightSig(Graphics g){
		int	[] xPoints = { (Center-30), (Center+10), (Center+10), (Center+30), (Center+10), (Center+10), (Center-30)};
		int	[] yPoints = { 290, 290, 275, 300, 325, 310,310};
		g.setColor(theColor);
		Polygon p = new Polygon(xPoints, yPoints, nPoints);
		g.fillPolygon(p);
	}
	
	public void Reset(Graphics g){
		g.setColor(Color.BLACK);
		g.fillOval(Center-40, 80, 75, 75);
		g.fillOval(Center-40, 170, 75, 75);
		g.fillOval(Center-40, 260, 75, 75);
		reset = false;
	}
    public void actionPerformed(ActionEvent ae) {
		if(ae.getSource() == Normal){
			NSig = true;
			SSig = false;
			CSig = false;
			RSig = false;
			reset = false;
			repaint();
		}
		else if(ae.getSource() == Stop){
			NSig = false;
			SSig = true;
			CSig = false;
			RSig = false;
			reset = false;
			theColor = Color.RED;
			repaint();
			
		}
		else if(ae.getSource() == Caution){
			NSig = false;
			SSig = false;
			CSig = true;
			RSig = false;
			reset = false;
			theColor = Color.ORANGE;
			repaint();
		}
		else if(ae.getSource() == rTurn){
			NSig = false;
			SSig = false;
			CSig = false;
			RSig = true;
			reset = false;
			theColor = Color.GREEN;
			repaint();
        }
		else if(ae.getSource() == Off){
			NSig = false;
			SSig = false;
			CSig = false;
			RSig = false;
			reset = true;
			repaint();
		}
    }

	public void toggleColor(Graphics g){
		if(NSig == true)
			NormalSig(g);
		else if(SSig == true)
			StopSig(g);
		else if(CSig == true)
			CautionSig(g);
		else if(RSig == true)
			RightSig(g);
		else if(reset == true)
			Reset(g);
	}
    public boolean isBlinking() {return reset;}

	int Center;
	int	nPoints =7;
		
    Color theColor = Color.BLACK;
	
    boolean 
		NSig = false,
		SSig = false,
		CSig = false,
		RSig = false,
		reset = true,
		SysOff = false;
	
    Button 
		Normal,
		Stop,
		Caution,
		rTurn,
		Off;
}

class BlinkThread extends Thread {
    BlinkThread(BlinkCanvas blinkCanvas) {
        this.blinkCanvas = blinkCanvas;
    }

   	public void run() {
	System.err.println("test");
		while (true) {
			if (blinkCanvas.isBlinking()==false) {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {}
                blinkCanvas.toggleColor(new Graphics());
			}
	System.err.println("test2");
        }
	}
	BlinkCanvas blinkCanvas;
}
